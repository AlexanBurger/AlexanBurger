/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Upgrade extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Upgrade/costumes/costume1.svg", {
        x: 263.73874,
        y: -130.37434509776182
      }),
      new Costume("costume2", "./Upgrade/costumes/costume2.svg", {
        x: 285.00450000000006,
        y: -104.9039680795313
      })
    ];

    this.sounds = [new Sound("pop", "./Upgrade/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Show Again" },
        this.whenIReceiveShowAgain
      )
    ];
  }

  *whenGreenFlagClicked() {
    while (true) {
      if (
        this.mouse.down &&
        this.touching("mouse") &&
        this.stage.vars.menu == 0
      ) {
        this.stage.vars.menu += 1;
        while (!!this.mouse.down) {
          yield;
        }
        this.moveAhead();
        this.broadcast("Hide For Upgrade");
      }
      if (
        this.mouse.down &&
        this.touching("mouse") &&
        this.stage.vars.menu == 1
      ) {
        this.stage.vars.menu += 1;
        while (!!this.mouse.down) {
          yield;
        }
        this.moveAhead();
        this.broadcast("Show Again");
      }
      if (this.stage.vars.menu == 0) {
        this.goto(1, 40);
        this.costume = "costume1";
      }
      if (this.stage.vars.menu == 1) {
        this.goto(0, 25);
        this.costume = "costume2";
      }
      yield;
    }
  }

  *whenIReceiveShowAgain() {
    this.visible = true;
  }
}
