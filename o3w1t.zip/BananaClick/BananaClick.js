/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class BananaClick extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("normal banana", "./BananaClick/costumes/normal banana.svg", {
        x: 30.583335000000005,
        y: 19.351164065937127
      }),
      new Costume("more bananas", "./BananaClick/costumes/more bananas.svg", {
        x: 30.172624563318777,
        y: 34.389078005696916
      }),
      new Costume(
        "even more bananas",
        "./BananaClick/costumes/even more bananas.svg",
        { x: 30.55335809960718, y: 26.803488175161505 }
      ),
      new Costume(
        "healthier bananas",
        "./BananaClick/costumes/healthier bananas.svg",
        { x: 38.47278011176573, y: 35.80639362552921 }
      ),
      new Costume(
        "healthiest bananas",
        "./BananaClick/costumes/healthiest bananas.svg",
        { x: 25.126040985419024, y: 31.913132353276637 }
      ),
      new Costume(
        "mutated bananas",
        "./BananaClick/costumes/mutated bananas.svg",
        { x: 34.688569563318794, y: 43.43014398585575 }
      ),
      new Costume(
        "oceanic bananas",
        "./BananaClick/costumes/oceanic bananas.svg",
        { x: 26.836011545470853, y: 35.12503261278411 }
      ),
      new Costume("lunar banana", "./BananaClick/costumes/lunar banana.svg", {
        x: 40.790065220894604,
        y: 33.71341778700992
      }),
      new Costume(
        "martian banana",
        "./BananaClick/costumes/martian banana.svg",
        { x: 38.47278011176573, y: 35.80639353345114 }
      ),
      new Costume("alien bananas", "./BananaClick/costumes/alien bananas.svg", {
        x: 36.28946453717816,
        y: 33.5160665825498
      }),
      new Costume(
        "radioactive bananas",
        "./BananaClick/costumes/radioactive bananas.svg",
        { x: 34.19111000000001, y: 28.637254907921886 }
      ),
      new Costume(
        "atomic bananas",
        "./BananaClick/costumes/atomic bananas.svg",
        { x: 34.19110870361328, y: 28.637254622887752 }
      ),
      new Costume(
        "angelic bananas",
        "./BananaClick/costumes/angelic bananas.svg",
        { x: 64.24532332470932, y: 43.81285348882761 }
      ),
      new Costume("extra bananas", "./BananaClick/costumes/extra bananas.svg", {
        x: 34.19111000000001,
        y: 26.137254907921886
      })
    ];

    this.sounds = [new Sound("pop", "./BananaClick/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Hide For Upgrade" },
        this.whenIReceiveHideForUpgrade
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Show Again" },
        this.whenIReceiveShowAgain
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked4)
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = true;
    this.stage.vars.upgrade = 0;
    this.stage.vars.multiplier = 1;
    this.stage.vars.cents = 0;
    this.stage.vars.money = 0;
    this.stage.vars.rebirthMultiplier = 1;
    this.effects.ghost = 99;
    this.goto(0, 0);
    this.size = 333;
    this.direction = 130;
    while (true) {
      this.goto(this.sprites["MovingBanana"].x, this.sprites["MovingBanana"].y);
      if (
        this.mouse.down &&
        this.touching("mouse") &&
        this.stage.vars.menu == 0 &&
        this.stage.vars.rebirth == 0
      ) {
        this.stage.vars.money +=
          1 * this.stage.vars.multiplier * this.stage.vars.rebirthMultiplier;
        while (!!this.mouse.down) {
          yield;
        }
        this.createClone();
      } else {
        if (
          this.mouse.down &&
          this.touching("mouse") &&
          this.stage.vars.menu == 0 &&
          this.stage.vars.rebirth > 0
        ) {
          this.stage.vars.money +=
            1 * this.stage.vars.multiplier * this.stage.vars.rebirthMultiplier;
          while (!!this.mouse.down) {
            yield;
          }
          this.createClone();
        }
      }
      yield;
    }
  }

  *startAsClone() {
    this.moveBehind();
    this.size = 100;
    this.effects.ghost = this.random(40, 70);
    this.goto(this.random(-200, 200), 200);
    this.direction = this.random(1, 359);
    while (true) {
      if (!(this.touching(this.sprites["Border"].andClones()) && this.y < 50)) {
        for (let i = 0; i < 10; i++) {
          this.direction += 4;
          for (let i = 0; i < 10; i++) {
            this.direction += 5;
            this.y += -7;
            for (let i = 0; i < 2; i++) {
              this.direction += 6;
              this.y += -6;
              for (let i = 0; i < 2; i++) {
                this.y += -5;
                yield;
              }
              yield;
            }
            yield;
          }
          this.deleteThisClone();
          yield;
        }
      } else {
        for (let i = 0; i < 10; i++) {
          this.direction += 4;
          for (let i = 0; i < 10; i++) {
            this.direction += 5;
            this.y += 7;
            for (let i = 0; i < 2; i++) {
              this.direction += 6;
              this.y += -6;
              for (let i = 0; i < 2; i++) {
                this.y += 2;
                yield;
              }
              yield;
            }
            yield;
          }
          this.deleteThisClone();
          yield;
        }
      }
      yield;
    }
  }

  *whenIReceiveHideForUpgrade() {
    this.visible = false;
  }

  *whenIReceiveShowAgain() {
    this.visible = true;
  }

  *whenGreenFlagClicked2() {
    this.costume = "normal banana";
    while (true) {
      if (this.stage.vars.upgrade == 1) {
        this.costume = "more bananas";
        this.size = 290;
      }
      if (this.stage.vars.upgrade == 2) {
        this.costume = "even more bananas";
        this.size = 220;
      }
      if (this.stage.vars.upgrade == 3) {
        this.costume = "healthier bananas";
        this.size = 290;
      }
      if (this.stage.vars.upgrade == 4) {
        this.costume = "healthiest bananas";
        this.size = 220;
      }
      if (this.stage.vars.upgrade == 5) {
        this.costume = "mutated bananas";
        this.size = 220;
      }
      if (this.stage.vars.upgrade == 6) {
        this.costume = "oceanic bananas";
        this.size = 290;
      }
      if (this.stage.vars.upgrade == 7) {
        this.costume = "lunar banana";
        this.size = 220;
      }
      if (this.stage.vars.upgrade == 8) {
        this.costume = "martian banana";
        this.size = 290;
      }
      if (this.stage.vars.upgrade == 9) {
        this.costume = "alien bananas";
        this.size = 220;
      }
      if (this.stage.vars.upgrade == 10) {
        this.costume = "radioactive bananas";
        this.size = 290;
      }
      if (this.stage.vars.upgrade == 11) {
        this.costume = "atomic bananas";
        this.size = 220;
      }
      if (this.stage.vars.upgrade == 12) {
        this.costume = "angelic bananas";
        this.size = 290;
      }
      if (this.stage.vars.upgrade == 13) {
        this.costume = "extra bananas";
        this.size = 220;
      }
      yield;
    }
  }

  *whenGreenFlagClicked3() {
    while (true) {
      if (this.stage.vars.money < 100000 || this.stage.vars.money == 99999) {
        this.stage.vars.typeOfMoney = " $";
      }
      if (
        (this.stage.vars.money < 1000000 || this.stage.vars.money == 1000000) &&
        (this.stage.vars.money == 100000 || this.stage.vars.money > 100000)
      ) {
        this.stage.vars.typeOfMoney = "K $";
      }
      if (
        (this.stage.vars.money < 100000000000 ||
          this.stage.vars.money == 100000000000) &&
        (this.stage.vars.money == 100000000 ||
          this.stage.vars.money > 100000000)
      ) {
        this.stage.vars.typeOfMoney = "M $";
      }
      yield;
    }
  }

  *whenGreenFlagClicked4() {
    while (true) {
      if (this.stage.vars.typeOfMoney == "M $") {
        this.stage.vars.cents =
          "" +
          Math.ceil(Math.floor(this.stage.vars.money) / 1000000) / 100 +
          this.stage.vars.typeOfMoney;
      } else {
        if (this.stage.vars.typeOfMoney == "K $") {
          this.stage.vars.cents =
            "" +
            Math.ceil(Math.floor(this.stage.vars.money) / 1000) / 100 +
            this.stage.vars.typeOfMoney;
        } else {
          this.stage.vars.cents =
            "" +
            Math.ceil(this.stage.vars.money) / 100 +
            this.stage.vars.typeOfMoney;
        }
      }
      if (this.stage.vars.rebirthMoney == "M $") {
        this.stage.vars.rebirthVisual =
          "" +
          Math.ceil(Math.floor(this.stage.vars.rebirthCost) / 1000000) / 100 +
          this.stage.vars.rebirthMoney;
      } else {
        if (this.stage.vars.rebirthMoney == "K $") {
          this.stage.vars.rebirthVisual =
            "" +
            Math.ceil(Math.floor(this.stage.vars.rebirthCost) / 1000) / 100 +
            this.stage.vars.rebirthMoney;
        } else {
          this.stage.vars.rebirthVisual =
            "" +
            Math.ceil(this.stage.vars.rebirthCost) / 100 +
            this.stage.vars.rebirthMoney;
        }
      }
      yield;
    }
  }
}
