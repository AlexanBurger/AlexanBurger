/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Upgrades extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("More Bananas", "./Upgrades/costumes/More Bananas.svg", {
        x: 88.72528500000001,
        y: 41.06388000000001
      }),
      new Costume(
        "Even More Bananas",
        "./Upgrades/costumes/Even More Bananas.svg",
        { x: 88.72527499999995, y: 41.063879999999955 }
      ),
      new Costume(
        "Healthier Bananas",
        "./Upgrades/costumes/Healthier Bananas.svg",
        { x: 88.72528499999967, y: 41.06387999999967 }
      ),
      new Costume(
        "Healthiest Bananas",
        "./Upgrades/costumes/Healthiest Bananas.svg",
        { x: 88.72527499999995, y: 41.063879999999955 }
      ),
      new Costume(
        "Mutated Bananas",
        "./Upgrades/costumes/Mutated Bananas.svg",
        { x: 88.72527500000001, y: 41.06388000000001 }
      ),
      new Costume(
        "Oceanic Bananas",
        "./Upgrades/costumes/Oceanic Bananas.svg",
        { x: 88.72526500000001, y: 41.06388000000001 }
      ),
      new Costume("Lunar Bananas", "./Upgrades/costumes/Lunar Bananas.svg", {
        x: 88.72525499999986,
        y: 41.0638799999999
      }),
      new Costume(
        "Martian Bananas",
        "./Upgrades/costumes/Martian Bananas.svg",
        { x: 88.7252549999996, y: 41.06387999999973 }
      ),
      new Costume("Alien Bananas", "./Upgrades/costumes/Alien Bananas.svg", {
        x: 88.725255,
        y: 41.06388000000001
      }),
      new Costume(
        "Radioactive Bananas",
        "./Upgrades/costumes/Radioactive Bananas.svg",
        { x: 88.72524499999992, y: 41.063879999999955 }
      ),
      new Costume("Atomic Bananas", "./Upgrades/costumes/Atomic Bananas.svg", {
        x: 88.72523499999994,
        y: 41.063879999999955
      }),
      new Costume(
        "Angelic Bananas",
        "./Upgrades/costumes/Angelic Bananas.svg",
        { x: 88.725235, y: 41.06388000000001 }
      ),
      new Costume("Extra Bananas", "./Upgrades/costumes/Extra Bananas.svg", {
        x: 88.725225,
        y: 41.06388000000001
      }),
      new Costume(
        "revived bananas",
        "./Upgrades/costumes/revived bananas.svg",
        { x: 88.7252149999999, y: 41.063879999999955 }
      ),
      new Costume("Coming Soon", "./Upgrades/costumes/Coming Soon.svg", {
        x: 88.72521499999999,
        y: 41.06388000000001
      })
    ];

    this.sounds = [new Sound("pop", "./Upgrades/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3)
    ];
  }

  *whenGreenFlagClicked() {
    this.costume = "More Bananas";
    this.visible = false;
    this.goto(10000000, 1000000);
    this.size = 1;
    while (true) {
      if (this.stage.vars.menu == 1) {
        this.visible = true;
        this.goto(-100, 28);
        this.size = 130;
      }
      if (this.stage.vars.menu == 2 || this.stage.vars.menu == 0) {
        this.goto(10000000, 1000000);
        this.size = 1;
        this.visible = false;
      }
      if (this.stage.vars.upgrade == 1) {
        this.stage.vars.multiplier = 2;
      }
      if (this.stage.vars.upgrade == 2) {
        this.stage.vars.multiplier = 3;
      }
      if (this.stage.vars.upgrade == 3) {
        this.stage.vars.multiplier = 12;
      }
      if (this.stage.vars.upgrade == 4) {
        this.stage.vars.multiplier = 48;
      }
      if (this.stage.vars.upgrade == 5) {
        this.stage.vars.multiplier = 128;
      }
      if (this.stage.vars.upgrade == 6) {
        this.stage.vars.multiplier = 444;
      }
      if (this.stage.vars.upgrade == 7) {
        this.stage.vars.multiplier = 2048;
      }
      if (this.stage.vars.upgrade == 8) {
        this.stage.vars.multiplier = 4096;
      }
      if (this.stage.vars.upgrade == 9) {
        this.stage.vars.multiplier = 16374;
      }
      if (this.stage.vars.upgrade == 10) {
        this.stage.vars.multiplier = 32000;
      }
      if (this.stage.vars.upgrade == 11) {
        this.stage.vars.multiplier = 64000;
      }
      if (this.stage.vars.upgrade == 12) {
        this.stage.vars.multiplier = 128000;
      }
      if (this.stage.vars.upgrade == 13) {
        this.stage.vars.multiplier = 333666;
      }
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    while (true) {
      if (this.stage.vars.upgrade == 0) {
        this.costume = "More Bananas";
      }
      if (
        this.costumeNumber == 1 &&
        this.touching("mouse") &&
        this.mouse.down &&
        (this.stage.vars.money == 50 || this.stage.vars.money > 50)
      ) {
        this.stage.vars.money = this.stage.vars.money - 50;
        this.costumeNumber += 1;
        this.stage.vars.upgrade += 1;
        while (!!this.mouse.down) {
          yield;
        }
      }
      if (
        this.costumeNumber == 2 &&
        this.touching("mouse") &&
        this.mouse.down &&
        (this.stage.vars.money == 100 || this.stage.vars.money > 100)
      ) {
        this.stage.vars.money = this.stage.vars.money - 100;
        this.costumeNumber += 1;
        this.stage.vars.upgrade += 1;
        while (!!this.mouse.down) {
          yield;
        }
      }
      if (
        this.costumeNumber == 3 &&
        this.touching("mouse") &&
        this.mouse.down &&
        (this.stage.vars.money == 500 || this.stage.vars.money > 500)
      ) {
        this.stage.vars.money = this.stage.vars.money - 500;
        this.costumeNumber += 1;
        this.stage.vars.upgrade += 1;
        while (!!this.mouse.down) {
          yield;
        }
      }
      if (
        this.costumeNumber == 4 &&
        this.touching("mouse") &&
        this.mouse.down &&
        (this.stage.vars.money == 2500 || this.stage.vars.money > 2500)
      ) {
        this.stage.vars.money = this.stage.vars.money - 2500;
        this.costumeNumber += 1;
        this.stage.vars.upgrade += 1;
        while (!!this.mouse.down) {
          yield;
        }
      }
      if (
        this.costumeNumber == 5 &&
        this.touching("mouse") &&
        this.mouse.down &&
        (this.stage.vars.money == 5000 || this.stage.vars.money > 5000)
      ) {
        this.stage.vars.money = this.stage.vars.money - 5000;
        this.costumeNumber += 1;
        this.stage.vars.upgrade += 1;
        while (!!this.mouse.down) {
          yield;
        }
      }
      if (
        this.costumeNumber == 6 &&
        this.touching("mouse") &&
        this.mouse.down &&
        (this.stage.vars.money == 10000 || this.stage.vars.money > 10000)
      ) {
        this.stage.vars.money = this.stage.vars.money - 10000;
        this.costumeNumber += 1;
        this.stage.vars.upgrade += 1;
        while (!!this.mouse.down) {
          yield;
        }
      }
      if (
        this.costumeNumber == 7 &&
        this.touching("mouse") &&
        this.mouse.down &&
        (this.stage.vars.money == 50000 || this.stage.vars.money > 50000)
      ) {
        this.stage.vars.money = this.stage.vars.money - 50000;
        this.costumeNumber += 1;
        this.stage.vars.upgrade += 1;
        while (!!this.mouse.down) {
          yield;
        }
      }
      if (
        this.costumeNumber == 8 &&
        this.touching("mouse") &&
        this.mouse.down &&
        (this.stage.vars.money == 250000 || this.stage.vars.money > 250000)
      ) {
        this.stage.vars.money = this.stage.vars.money - 250000;
        this.costumeNumber += 1;
        this.stage.vars.upgrade += 1;
        while (!!this.mouse.down) {
          yield;
        }
      }
      if (
        this.costumeNumber == 9 &&
        this.touching("mouse") &&
        this.mouse.down &&
        (this.stage.vars.money == 1000000 || this.stage.vars.money > 1000000)
      ) {
        this.stage.vars.money = this.stage.vars.money - 1000000;
        this.costumeNumber += 1;
        this.stage.vars.upgrade += 1;
        while (!!this.mouse.down) {
          yield;
        }
      }
      if (
        this.costumeNumber == 10 &&
        this.touching("mouse") &&
        this.mouse.down &&
        (this.stage.vars.money == 5000000 || this.stage.vars.money > 5000000)
      ) {
        this.stage.vars.money = this.stage.vars.money - 5000000;
        this.costumeNumber += 1;
        this.stage.vars.upgrade += 1;
        while (!!this.mouse.down) {
          yield;
        }
      }
      if (
        this.costumeNumber == 11 &&
        this.touching("mouse") &&
        this.mouse.down &&
        (this.stage.vars.money == 10000000 || this.stage.vars.money > 10000000)
      ) {
        this.stage.vars.money = this.stage.vars.money - 10000000;
        this.costumeNumber += 1;
        this.stage.vars.upgrade += 1;
        while (!!this.mouse.down) {
          yield;
        }
      }
      if (
        this.costumeNumber == 12 &&
        this.touching("mouse") &&
        this.mouse.down &&
        (this.stage.vars.cents == "250K $" || this.stage.vars.money > 25000000)
      ) {
        this.stage.vars.money = this.stage.vars.money - 25000000;
        this.costumeNumber += 1;
        this.stage.vars.upgrade += 1;
        while (!!this.mouse.down) {
          yield;
        }
      }
      if (
        this.costumeNumber == 13 &&
        this.touching("mouse") &&
        this.mouse.down &&
        (this.stage.vars.cents == "500K $" || this.stage.vars.money > 50000000)
      ) {
        this.stage.vars.money = this.stage.vars.money - 50000000;
        this.costumeNumber += 1;
        this.stage.vars.upgrade += 1;
        while (!!this.mouse.down) {
          yield;
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked3() {
    while (true) {
      if (this.stage.vars.rebirth > 1) {
        this.stage.vars.rebirthMultiplier = this.stage.vars.rebirth * 2;
      }
      yield;
    }
  }
}
