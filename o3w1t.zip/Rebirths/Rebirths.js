/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Rebirths extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Rebirths/costumes/costume1.svg", {
        x: 170.7763951248844,
        y: 102.5955378399459
      })
    ];

    this.sounds = [
      new Sound("pop", "./Rebirths/sounds/pop.wav"),
      new Sound("Baa", "./Rebirths/sounds/Baa.wav")
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked4)
    ];
  }

  *whenGreenFlagClicked() {
    while (true) {
      if (this.stage.vars.menu == 1) {
        this.visible = true;
        this.goto(100, 28);
        this.size = 50;
        this.stage.watchers.rebirthVisual.visible = true;
        this.stage.watchers.rebirth.visible = true;
      }
      if (this.stage.vars.menu == 2 || this.stage.vars.menu == 0) {
        this.goto(10000000, 1000000);
        this.size = 1;
        this.visible = false;
        this.stage.watchers.rebirthVisual.visible = false;
        this.stage.watchers.rebirth.visible = false;
      }
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    this.stage.vars.cents = 0;
    this.stage.vars.clones = 0;
    this.stage.vars.menu = 0;
    this.stage.vars.money = 0;
    this.stage.vars.rebirth = 1;
    this.stage.vars.rebirthCost = 0;
    this.stage.vars.rebirthMoney = 0;
    this.stage.vars.rebirthVisual = 0;
    this.stage.vars.upgrade = 0;
    this.stage.vars.rebirthAmountNumber = 1;
  }

  *whenGreenFlagClicked3() {
    while (true) {
      if (
        this.touching("mouse") &&
        this.mouse.down &&
          (this.stage.vars.money == this.stage.vars.rebirthCost ||
            this.stage.vars.money > this.stage.vars.rebirthCost)
      ) {
        this.stage.vars.money = 0;
        this.stage.vars.multiplier = 1;
        this.stage.vars.upgrade = 0;
        this.stage.vars.rebirth += this.stage.vars.rebirthAmount;
        while (!!(this.touching("mouse") && this.mouse.down)) {
          yield;
        }
      }
      if (
        this.touching("mouse") &&
        this.mouse.down &&
          !(
            this.stage.vars.rebirthVisual == this.stage.vars.cents ||
            this.stage.vars.cents > this.stage.vars.rebirthVisual
          )
      ) {
        yield* this.startSound("Baa");
      }
      yield;
    }
  }

  *whenGreenFlagClicked4() {
    while (true) {
      this.stage.vars.rebirthCost =
        (99 + 100000000 * this.stage.vars.rebirth) *
        this.stage.vars.rebirthAmountNumber;
      this.stage.vars.rebirthAmount = this.stage.vars.rebirthAmountNumber;
      if (this.stage.vars.money > this.stage.vars.rebirthCost) {
        this.stage.vars.rebirthAmountNumber += 1;
      }
      if (
        this.stage.vars.rebirthCost > 99999999999 &&
        this.stage.vars.rebirthCost < 100000000000000
      ) {
        this.stage.vars.rebirthMoney = "B $";
      } else {
        if (
          this.stage.vars.rebirthCost > 99999999 &&
          this.stage.vars.rebirthCost < 100000000000
        ) {
          this.stage.vars.rebirthMoney = "M $";
        } else {
          if (
            this.stage.vars.rebirthCost > 99999 &&
            this.stage.vars.rebirthCost < 100000000
          ) {
            this.stage.vars.rebirthMoney = "K $";
          } else {
            this.stage.vars.rebirthMoney = " $";
          }
        }
      }
      yield;
    }
  }
}
