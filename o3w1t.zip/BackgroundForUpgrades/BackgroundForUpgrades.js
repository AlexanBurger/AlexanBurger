/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class BackgroundForUpgrades extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./BackgroundForUpgrades/costumes/costume1.svg", {
        x: 280.7659895508699,
        y: 249.2462726355489
      }),
      new Costume("costume4", "./BackgroundForUpgrades/costumes/costume4.svg", {
        x: 280.7659895508699,
        y: 249.2462726355489
      }),
      new Costume("costume3", "./BackgroundForUpgrades/costumes/costume3.svg", {
        x: 280.7659743436358,
        y: 249.24627358331264
      }),
      new Costume("costume2", "./BackgroundForUpgrades/costumes/costume2.svg", {
        x: 280.76597389450575,
        y: 249.2462712188614
      }),
      new Costume("costume5", "./BackgroundForUpgrades/costumes/costume5.svg", {
        x: 280.76597389450575,
        y: 249.2462712188614
      }),
      new Costume("costume6", "./BackgroundForUpgrades/costumes/costume6.svg", {
        x: 280.76597389450575,
        y: 249.2462712188614
      }),
      new Costume("costume7", "./BackgroundForUpgrades/costumes/costume7.svg", {
        x: 280.76597389450575,
        y: 249.2462712188614
      })
    ];

    this.sounds = [new Sound("pop", "./BackgroundForUpgrades/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked)
    ];
  }

  *whenGreenFlagClicked() {
    this.goto(0, 0);
    this.stage.vars.menu = 0;
    while (true) {
      this.visible = false;
      if (this.stage.vars.menu == 1) {
        this.visible = true;
        yield* this.wait(0.000001);
        this.costumeNumber += 1;
      }
      if (this.stage.vars.menu == 2) {
        this.visible = false;
        this.stage.vars.menu = 0;
      }
      yield;
    }
  }
}
