/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class MovingBanana extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume(
        "Regular banana",
        "./MovingBanana/costumes/Regular banana.svg",
        { x: 30.583335000000005, y: 19.351164065937127 }
      ),
      new Costume("more bananas", "./MovingBanana/costumes/more bananas.svg", {
        x: 30.172624563318777,
        y: 34.389078005696916
      }),
      new Costume(
        "even more bananas",
        "./MovingBanana/costumes/even more bananas.svg",
        { x: 30.55335809960718, y: 26.803488175161505 }
      ),
      new Costume(
        "healthier bananas",
        "./MovingBanana/costumes/healthier bananas.svg",
        { x: 38.47278011176573, y: 35.80639362552921 }
      ),
      new Costume(
        "healthiest bananas",
        "./MovingBanana/costumes/healthiest bananas.svg",
        { x: 25.126040985419024, y: 31.913132353276637 }
      ),
      new Costume(
        "mutated bananas",
        "./MovingBanana/costumes/mutated bananas.svg",
        { x: 34.688569563318794, y: 43.43014398585575 }
      ),
      new Costume(
        "Oceanic bananas",
        "./MovingBanana/costumes/Oceanic bananas.svg",
        { x: 26.836011545470853, y: 35.12503261278411 }
      ),
      new Costume("lunar banana", "./MovingBanana/costumes/lunar banana.svg", {
        x: 38.22278,
        y: 33.42211901933493
      }),
      new Costume(
        "martian banana",
        "./MovingBanana/costumes/martian banana.svg",
        { x: 38.47278011176573, y: 35.80639353345114 }
      ),
      new Costume(
        "alien bananas",
        "./MovingBanana/costumes/alien bananas.svg",
        { x: 36.28945513471206, y: 33.51606200540601 }
      ),
      new Costume(
        "radioactive bananas",
        "./MovingBanana/costumes/radioactive bananas.svg",
        { x: 34.19111000000001, y: 28.637254907921886 }
      ),
      new Costume(
        "atomic bananas",
        "./MovingBanana/costumes/atomic bananas.svg",
        { x: 34.19110870361328, y: 28.637254622887752 }
      ),
      new Costume(
        "angelic bananas",
        "./MovingBanana/costumes/angelic bananas.svg",
        { x: 64.24532332470932, y: 43.81285348882761 }
      ),
      new Costume(
        "extra bananas",
        "./MovingBanana/costumes/extra bananas.svg",
        { x: 34.19111000000001, y: 26.137254907921886 }
      )
    ];

    this.sounds = [new Sound("pop", "./MovingBanana/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Hide For Upgrade" },
        this.whenIReceiveHideForUpgrade
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Show Again" },
        this.whenIReceiveShowAgain
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2)
    ];
  }

  *whenGreenFlagClicked() {
    this.stage.watchers.cents.visible = true;
    this.direction = 130;
    this.costume = "Regular banana";
    this.visible = true;
    this.goto(0, 0);
    this.size = 333;
    while (true) {
      if (this.mouse.down && this.touching("mouse")) {
        for (let i = 0; i < 3; i++) {
          this.size += 10;
          yield;
        }
        while (!!this.mouse.down) {
          yield;
        }
        for (let i = 0; i < 3; i++) {
          this.size += -10;
          yield;
        }
        for (let i = 0; i < 3; i++) {
          for (let i = 0; i < 5; i++) {
            this.goto(
              this.sprites["BananaClick"].x,
              this.sprites["BananaClick"].y
            );
            this.direction += 5;
            this.size += 1;
            yield;
          }
          for (let i = 0; i < 5; i++) {
            this.goto(
              this.sprites["BananaClick"].x,
              this.sprites["BananaClick"].y
            );
            this.direction -= 5;
            this.size += -1;
            yield;
          }
          yield;
        }
      } else {
        this.goto(this.sprites["BananaClick"].x, this.sprites["BananaClick"].y);
      }
      yield;
    }
  }

  *whenIReceiveHideForUpgrade() {
    this.visible = false;
  }

  *whenIReceiveShowAgain() {
    this.visible = true;
  }

  *whenGreenFlagClicked2() {
    this.costume = "Regular banana";
    while (true) {
      if (this.stage.vars.upgrade == 1) {
        this.costume = "more bananas";
        this.size = 290;
      }
      if (this.stage.vars.upgrade == 2) {
        this.costume = "even more bananas";
        this.size = 220;
      }
      if (this.stage.vars.upgrade == 3) {
        this.costume = "healthier bananas";
        this.size = 290;
      }
      if (this.stage.vars.upgrade == 4) {
        this.costume = "healthiest bananas";
        this.size = 220;
      }
      if (this.stage.vars.upgrade == 5) {
        this.costume = "mutated bananas";
        this.size = 220;
      }
      if (this.stage.vars.upgrade == 6) {
        this.costume = "Oceanic bananas";
        this.size = 290;
      }
      if (this.stage.vars.upgrade == 7) {
        this.costume = "lunar banana";
        this.size = 220;
      }
      if (this.stage.vars.upgrade == 8) {
        this.costume = "martian banana";
        this.size = 290;
      }
      if (this.stage.vars.upgrade == 9) {
        this.costume = "alien bananas";
        this.size = 220;
      }
      if (this.stage.vars.upgrade == 10) {
        this.costume = "radioactive bananas";
        this.size = 290;
      }
      if (this.stage.vars.upgrade == 11) {
        this.costume = "atomic bananas";
        this.size = 220;
      }
      if (this.stage.vars.upgrade == 12) {
        this.costume = "angelic bananas";
        this.size = 290;
      }
      if (this.stage.vars.upgrade == 13) {
        this.costume = "extra bananas";
        this.size = 220;
      }
      yield;
    }
  }
}
