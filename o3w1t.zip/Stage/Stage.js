/* eslint-disable require-yield, eqeqeq */

import {
  Stage as StageBase,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Stage extends StageBase {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("backdrop1", "./Stage/costumes/backdrop1.svg", {
        x: 351.0743054459211,
        y: 286.03305942233567
      }),
      new Costume("backdrop5", "./Stage/costumes/backdrop5.svg", {
        x: 351.0743054459211,
        y: 286.03305942233567
      }),
      new Costume("backdrop4", "./Stage/costumes/backdrop4.svg", {
        x: 351.0743054459211,
        y: 286.03305942233567
      }),
      new Costume("backdrop3", "./Stage/costumes/backdrop3.svg", {
        x: 351.0742933834929,
        y: 286.033062184943
      }),
      new Costume("backdrop2", "./Stage/costumes/backdrop2.svg", {
        x: 351.0742933834929,
        y: 286.033062184943
      })
    ];

    this.sounds = [
      new Sound("pop", "./Stage/sounds/pop.wav"),
      new Sound("recording1", "./Stage/sounds/recording1.wav"),
      new Sound("Swiggly", "./Stage/sounds/Swiggly.mp3"),
      new Sound(
        "Banana clicker music",
        "./Stage/sounds/Banana clicker music.wav"
      )
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2)
    ];

    this.vars.menu = 0;
    this.vars.upgrade = 0;
    this.vars.cents = "0 $";
    this.vars.money = 0;
    this.vars.multiplier = 1;
    this.vars.typeOfMoney = " $";
    this.vars.var = 30.800000000000015;
    this.vars.clones = 0;
    this.vars.rebirthCost = 100000099;
    this.vars.rebirth = 1;
    this.vars.rebirthMoney = "M $";
    this.vars.rebirthVisual = "1.01M $";
    this.vars.rebirthMultiplier = 1;
    this.vars.rebirthNumber = 0;
    this.vars.rebirthAmount = 1;
    this.vars.rebirthAmountNumber = 1;

    this.watchers.cents = new Watcher({
      label: "Cents",
      style: "large",
      visible: false,
      value: () => this.vars.cents,
      x: 455,
      y: 151
    });
  }

  *whenGreenFlagClicked() {
    this.effects.color = 0;
    while (true) {
      this.costume = "next backdrop";
      this.effects.color += 0.001;
      this.costume = "random backdrop";
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    while (true) {
      yield* this.playSoundUntilDone("Banana clicker music");
      yield;
    }
  }
}
