import { Project } from "https://unpkg.com/leopard@^1/dist/index.esm.js";

import Stage from "./Stage/Stage.js";
import MovingBanana from "./MovingBanana/MovingBanana.js";
import BananaClick from "./BananaClick/BananaClick.js";
import Border from "./Border/Border.js";
import Upgrade from "./Upgrade/Upgrade.js";
import BackgroundForUpgrades from "./BackgroundForUpgrades/BackgroundForUpgrades.js";
import Upgrades from "./Upgrades/Upgrades.js";
import Thumbnail from "./Thumbnail/Thumbnail.js";
import Rebirths from "./Rebirths/Rebirths.js";

const stage = new Stage({ costumeNumber: 5 });

const sprites = {
  MovingBanana: new MovingBanana({
    x: -6,
    y: 12,
    direction: 130,
    costumeNumber: 1,
    size: 333,
    visible: true,
    layerOrder: 4
  }),
  BananaClick: new BananaClick({
    x: -6,
    y: 12,
    direction: 130,
    costumeNumber: 1,
    size: 333,
    visible: true,
    layerOrder: 2
  }),
  Border: new Border({
    x: 0,
    y: 0,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 7
  }),
  Upgrade: new Upgrade({
    x: 1,
    y: 40,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 6
  }),
  BackgroundForUpgrades: new BackgroundForUpgrades({
    x: 0,
    y: 0,
    direction: 90,
    costumeNumber: 6,
    size: 100,
    visible: false,
    layerOrder: 1
  }),
  Upgrades: new Upgrades({
    x: 243,
    y: 180,
    direction: 90,
    costumeNumber: 1,
    size: 6.2406311021033,
    visible: false,
    layerOrder: 5
  }),
  Thumbnail: new Thumbnail({
    x: 0,
    y: 0,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 8
  }),
  Rebirths: new Rebirths({
    x: 241,
    y: 181,
    direction: 90,
    costumeNumber: 1,
    size: 1.9442912610966947,
    visible: false,
    layerOrder: 3
  })
};

const project = new Project(stage, sprites, {
  frameRate: 30 // Set to 60 to make your project run faster
});
export default project;
