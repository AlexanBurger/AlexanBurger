/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Border extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Border/costumes/costume1.svg", {
        x: 272.72075363297097,
        y: 213.70514608225858
      }),
      new Costume("costume2", "./Border/costumes/costume2.svg", {
        x: 302.1827017738997,
        y: 244.35411186067478
      })
    ];

    this.sounds = [new Sound("pop", "./Border/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked)
    ];
  }

  *whenGreenFlagClicked() {
    this.goto(0, 0);
    this.effects.color = 0;
    while (true) {
      this.moveAhead();
      if (this.stage.vars.menu == 0) {
        this.goto(0, 0);
        this.costume = "costume1";
      }
      if (this.stage.vars.menu == 1) {
        this.goto(0, 0);
        this.costume = "costume2";
      }
      this.effects.color += 0.001;
      yield;
    }
  }
}
